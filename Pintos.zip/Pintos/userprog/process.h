#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"

tid_t process_execute (const char *file_name);
void process_exit (void);
void process_activate (void);
int process_wait (tid_t);


#endif /* userprog/process.h */
